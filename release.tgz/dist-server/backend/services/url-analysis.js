import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { chromium } from 'playwright';
import { urlAnalysisJobSchema } from '../../shared/analysis-types.js';
import { getStoragePaths } from '../storage.js';
import { lookupUrlThreatIntel } from './threat-intel.js';
const urlAnalysisJobs = new Map();
export class UrlAnalysisError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}
export async function enqueueUrlAnalysisJob(urls, analyzeUrlWithBrowser = analyzeUrlWithPlaywright, enrichUrlWithThreatIntel = lookupUrlThreatIntel, createJobId = randomUUID) {
    const normalizedUrls = normalizeAndValidateUrls(urls);
    const jobId = createJobId();
    const queuedJob = urlAnalysisJobSchema.parse({
        jobId,
        status: 'queued',
        queuedUrls: normalizedUrls.map((entry) => entry.originalUrl),
        results: [],
    });
    urlAnalysisJobs.set(jobId, queuedJob);
    queueMicrotask(async () => {
        await runUrlAnalysisJob(jobId, normalizedUrls, analyzeUrlWithBrowser, enrichUrlWithThreatIntel);
    });
    return queuedJob;
}
export async function getUrlAnalysisJob(jobId) {
    return urlAnalysisJobs.get(jobId) ?? null;
}
export async function createUrlAnalysisJob(urls, analyzeUrlWithBrowser, enrichUrlWithThreatIntel = lookupUrlThreatIntel, createJobId = randomUUID) {
    const normalizedUrls = normalizeAndValidateUrls(urls);
    const jobId = createJobId();
    const results = await Promise.all(normalizedUrls.map(async ({ originalUrl, normalizedUrl }, index) => {
        const [browserResult, externalScans] = await Promise.all([
            analyzeUrlWithBrowser(normalizedUrl, { jobId, index }),
            enrichUrlWithThreatIntel(normalizedUrl),
        ]);
        return {
            originalUrl,
            ...browserResult,
            externalScans,
        };
    }));
    return urlAnalysisJobSchema.parse({
        jobId,
        status: results.every((result) => result.status === 'completed') ? 'completed' : 'failed',
        queuedUrls: normalizedUrls.map((entry) => entry.originalUrl),
        results,
    });
}
async function runUrlAnalysisJob(jobId, normalizedUrls, analyzeUrlWithBrowser, enrichUrlWithThreatIntel) {
    urlAnalysisJobs.set(jobId, {
        jobId,
        status: 'running',
        queuedUrls: normalizedUrls.map((entry) => entry.originalUrl),
        results: [],
    });
    const results = [];
    for (const [index, entry] of normalizedUrls.entries()) {
        try {
            const [browserResult, externalScans] = await Promise.all([
                analyzeUrlWithBrowser(entry.normalizedUrl, { jobId, index }),
                enrichUrlWithThreatIntel(entry.normalizedUrl),
            ]);
            results.push({
                originalUrl: entry.originalUrl,
                ...browserResult,
                externalScans,
            });
        }
        catch (error) {
            results.push({
                externalScans: {
                    urlhaus: {
                        status: 'unavailable',
                        reference: null,
                        tags: [],
                        permalink: null,
                    },
                    virustotal: {
                        status: 'unavailable',
                        malicious: null,
                        suspicious: null,
                        reference: null,
                    },
                    urlscan: {
                        status: 'unavailable',
                        resultUrl: null,
                    },
                    alienVault: {
                        status: 'unavailable',
                        pulseCount: null,
                        reference: null,
                    },
                },
                originalUrl: entry.originalUrl,
                finalUrl: null,
                title: null,
                screenshotPath: null,
                tracePath: null,
                redirectChain: [],
                requestedDomains: [],
                scriptUrls: [],
                consoleErrors: [],
                status: 'failed',
                error: error instanceof Error ? error.message : 'URL analysis failed unexpectedly.',
            });
        }
    }
    urlAnalysisJobs.set(jobId, urlAnalysisJobSchema.parse({
        jobId,
        status: results.every((result) => result.status === 'completed') ? 'completed' : 'failed',
        queuedUrls: normalizedUrls.map((entry) => entry.originalUrl),
        results,
    }));
}
export async function analyzeUrlWithPlaywright(url, context) {
    const browser = await chromium.launch({ headless: true });
    const browserContext = await browser.newContext();
    const page = await browserContext.newPage();
    const redirectChain = [];
    const requestedDomains = new Set();
    const scriptUrls = new Set();
    const consoleErrors = [];
    const traceDirectory = path.join(getStoragePaths().traces, context.jobId);
    const tracePath = path.join(traceDirectory, createSafeTraceFilename(url, context.index));
    await fs.mkdir(traceDirectory, { recursive: true });
    await browserContext.tracing.start({ screenshots: true, snapshots: true, sources: true });
    page.on('request', (request) => {
        try {
            const hostname = new URL(request.url()).hostname;
            requestedDomains.add(hostname);
            if (request.resourceType() === 'script') {
                scriptUrls.add(request.url());
            }
        }
        catch {
            return;
        }
    });
    page.on('response', (response) => {
        if (response.request().isNavigationRequest()) {
            redirectChain.push(response.url());
        }
    });
    page.on('console', (message) => {
        if (message.type() === 'error') {
            consoleErrors.push(message.text());
        }
    });
    try {
        const response = await page.goto(url, {
            waitUntil: 'domcontentloaded',
            timeout: 15000,
        });
        const screenshotDirectory = path.join(getStoragePaths().screenshots, context.jobId);
        await fs.mkdir(screenshotDirectory, { recursive: true });
        const screenshotPath = path.join(screenshotDirectory, createSafeFilename(url, context.index));
        await page.screenshot({ path: screenshotPath, fullPage: true });
        const title = await page.title();
        const finalUrl = page.url();
        if (!redirectChain.length && response?.url()) {
            redirectChain.push(response.url());
        }
        if (!redirectChain.includes(finalUrl)) {
            redirectChain.push(finalUrl);
        }
        return {
            finalUrl,
            title: title || null,
            screenshotPath,
            tracePath,
            redirectChain,
            requestedDomains: [...requestedDomains],
            scriptUrls: [...scriptUrls],
            consoleErrors,
            status: 'completed',
            error: null,
            externalScans: {
                urlhaus: {
                    status: 'unavailable',
                    reference: null,
                    tags: [],
                    permalink: null,
                },
                virustotal: {
                    status: 'unavailable',
                    malicious: null,
                    suspicious: null,
                    reference: null,
                },
                urlscan: {
                    status: 'unavailable',
                    resultUrl: null,
                },
                alienVault: {
                    status: 'unavailable',
                    pulseCount: null,
                    reference: null,
                },
            },
        };
    }
    catch (error) {
        return {
            externalScans: {
                urlhaus: {
                    status: 'unavailable',
                    reference: null,
                    tags: [],
                    permalink: null,
                },
                virustotal: {
                    status: 'unavailable',
                    malicious: null,
                    suspicious: null,
                    reference: null,
                },
                urlscan: {
                    status: 'unavailable',
                    resultUrl: null,
                },
                alienVault: {
                    status: 'unavailable',
                    pulseCount: null,
                    reference: null,
                },
            },
            finalUrl: null,
            title: null,
            screenshotPath: null,
            tracePath: null,
            redirectChain,
            requestedDomains: [...requestedDomains],
            scriptUrls: [...scriptUrls],
            consoleErrors,
            status: 'failed',
            error: error instanceof Error ? error.message : 'Playwright analysis failed unexpectedly.',
        };
    }
    finally {
        await browserContext.tracing.stop({ path: tracePath });
        await page.close();
        await browserContext.close();
        await browser.close();
    }
}
function normalizeAndValidateUrls(urls) {
    const normalizedUrls = [...new Map(urls.map((url) => {
            const trimmedUrl = url.trim();
            const normalizedUrl = normalizePublicUrl(trimmedUrl);
            return [normalizedUrl, { originalUrl: trimmedUrl, normalizedUrl }];
        })).values()];
    if (normalizedUrls.length === 0) {
        throw new UrlAnalysisError('invalid_url_target', 'At least one public URL is required for analysis.');
    }
    return normalizedUrls;
}
function normalizePublicUrl(value) {
    let parsedUrl;
    try {
        parsedUrl = new URL(value);
    }
    catch {
        throw new UrlAnalysisError('invalid_url_target', 'One or more URLs are invalid.');
    }
    if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
        throw new UrlAnalysisError('invalid_url_target', 'Only HTTP(S) URLs can be analyzed.');
    }
    const hostname = parsedUrl.hostname.toLowerCase();
    if (hostname === 'localhost' ||
        hostname === '::1' ||
        hostname.startsWith('127.') ||
        hostname.startsWith('10.') ||
        hostname.startsWith('192.168.') ||
        /^172\.(1[6-9]|2\d|3[0-1])\./.test(hostname)) {
        throw new UrlAnalysisError('invalid_url_target', 'Local, loopback, and private-network URLs are blocked.');
    }
    return parsedUrl.toString();
}
function createSafeFilename(url, index) {
    const hostname = new URL(url).hostname.replace(/[^a-z0-9.-]/gi, '-');
    return `${index.toString().padStart(2, '0')}-${hostname}.png`;
}
function createSafeTraceFilename(url, index) {
    const hostname = new URL(url).hostname.replace(/[^a-z0-9.-]/gi, '-');
    return `${index.toString().padStart(2, '0')}-${hostname}.zip`;
}
