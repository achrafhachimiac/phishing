import { simpleParser } from 'mailparser';
import { emailParsingResponseSchema } from '../../shared/analysis-types.js';
export class EmailParsingError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}
export async function parseRawEmail(rawEmail) {
    const trimmedEmail = rawEmail.trim();
    if (!trimmedEmail) {
        throw new EmailParsingError('invalid_email', 'Raw email is required.');
    }
    const parsedEmail = await simpleParser(trimmedEmail);
    const authenticationHeader = parsedEmail.headers.get('authentication-results');
    const returnPathHeader = headerValue(parsedEmail.headers.get('return-path')) || extractHeader(trimmedEmail, 'return-path');
    const combinedContent = [parsedEmail.text, parsedEmail.html]
        .filter((part) => typeof part === 'string' && part.length > 0)
        .join('\n');
    const emailAddresses = uniqueMatches(`${trimmedEmail}\n${combinedContent}`, /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63}/gi);
    const domains = [...new Set(emailAddresses.map((emailAddress) => emailAddress.split('@')[1].toLowerCase()))];
    const ipAddresses = uniqueMatches(trimmedEmail, /\b(?:\d{1,3}\.){3}\d{1,3}\b/g);
    const urls = uniqueMatches(combinedContent || trimmedEmail, /https?:\/\/[^\s<>"]+/gi).map((url) => ({
        originalUrl: url,
        decodedUrl: decodeUrl(url),
    }));
    return emailParsingResponseSchema.parse({
        headers: {
            from: extractAddressText(parsedEmail.from),
            to: extractAddressText(parsedEmail.to),
            subject: parsedEmail.subject || null,
            date: parsedEmail.date?.toUTCString() || null,
            messageId: headerValue(parsedEmail.headers.get('message-id')),
            returnPath: returnPathHeader,
        },
        authentication: {
            spf: extractAuthenticationResult(authenticationHeader, 'spf'),
            dkim: extractAuthenticationResult(authenticationHeader, 'dkim'),
            dmarc: extractAuthenticationResult(authenticationHeader, 'dmarc'),
        },
        urls,
        emailAddresses,
        domains,
        ipAddresses,
        attachments: parsedEmail.attachments.map((attachment) => ({
            filename: attachment.filename || null,
            contentType: attachment.contentType,
            size: attachment.size,
            checksum: attachment.checksum || null,
        })),
    });
}
function headerValue(value) {
    if (typeof value === 'string') {
        return value;
    }
    if (value && typeof value === 'object' && 'text' in value && typeof value.text === 'string') {
        return value.text;
    }
    return null;
}
function extractAddressText(value) {
    if (value && typeof value === 'object' && 'text' in value && typeof value.text === 'string') {
        return value.text;
    }
    return null;
}
function extractHeader(rawEmail, headerName) {
    const match = rawEmail.match(new RegExp(`^${headerName}:\s*(.+)$`, 'im'));
    return match?.[1]?.trim() || null;
}
function decodeUrl(url) {
    try {
        return decodeURIComponent(url);
    }
    catch {
        return url;
    }
}
function uniqueMatches(content, pattern) {
    return [...new Set(content.match(pattern) ?? [])];
}
function extractAuthenticationResult(header, key) {
    if (typeof header !== 'string') {
        return null;
    }
    const match = header.match(new RegExp(`${key}=([a-zA-Z]+)`, 'i'));
    return match?.[1]?.toLowerCase() || null;
}
