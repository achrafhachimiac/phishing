import fs from 'node:fs';
import path from 'node:path';
import { appConfig } from './config.js';
export function getStoragePaths() {
    return {
        root: appConfig.storageRoot,
        reports: path.join(appConfig.storageRoot, 'reports'),
        screenshots: path.join(appConfig.storageRoot, 'screenshots'),
        traces: path.join(appConfig.storageRoot, 'traces'),
    };
}
export function ensureStorageDirectories() {
    const storagePaths = getStoragePaths();
    Object.values(storagePaths).forEach((targetPath) => {
        fs.mkdirSync(targetPath, { recursive: true });
    });
    return storagePaths;
}
